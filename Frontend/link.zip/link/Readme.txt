setup:
1. run pip install requirments.py
2. run python link.py
3. enter your username, location where you want the projects to start
4. you will be asked to choose a server for link to run on
5- connect to link from the codavia clint